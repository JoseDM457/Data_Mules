#include <Data_Mules_Management.h>
#include <RadioLib.h>

#define DS18B20_PIN A0
#define FC28_PIN A1 
EstacionBastWAN estacion(DS18B20_PIN);// Instanciamos librería pasándole el pin del DS18B20

uint8_t payload[25]; //Datos recopilados 
uint8_t huella[3] = {0xFF, 0xFF, 0xFF}; //trackeo de los dispositivos por lo que paso 
uint8_t payload_P2P_send[28]; //Arreglo para la trama que se envia por Radio
uint8_t payload_P2P_received[28];//Arreglo para la trama que se recibe por Radio

//Es AE, diferencia entre el mensaje de 1 = 128 o 0=186
bool esAE = 0; // 1 = No SD (AE), 0 = Sí SD (JL)
uint8_t ID_mi_estacion = 9;
uint8_t connection_hits_mi_estacion = 4;  

uint8_t message_function = 4; //0 Discovery, 1 JL, 2 AE, 3 ACK
bool delete_flag = 0;

bool externo_esAE = 1;
uint8_t ID_estacion_externa = 6;
uint8_t connection_hits_estacion_externa = 0;

SX1276 radio = new Module(SS, RFM_DIO0, RFM_RST, RFM_DIO1);
LoRaWANNode node(&radio, &US915, 2);

//
uint64_t joinEUI = 0x4677866767767676;
uint64_t devEUI  = 0x70B3D57ED007866D;

uint8_t newKey[] = {
  0xE2, 0x4D, 0x3E, 0x63, 0xF5, 0x9A, 0xF4, 0xB0, 0x52, 0xE7, 0x89, 0xF3, 0x30, 0x9B, 0xE3, 0x9A
};

uint8_t appKey[] = {
  0xE2, 0x4D, 0x3E, 0x63, 0xF5, 0x9A, 0xF4, 0xB0, 0x52, 0xE7, 0x89, 0xF3, 0x30, 0x9B, 0xE3, 0x9A
};


/**
 * Envía tu arreglo de 25 bytes y verifica si el Gateway respondió con un ACK.
 * Retorna true si fue exitoso, false si no hubo confirmación.
 */
bool enviarArregloDirecto(uint8_t* miPayload, uint8_t tamano) {
  Serial.print("Transmitiendo arreglo de ");
  Serial.print(tamano);
  Serial.println(" bytes...");

  // Parámetros: datos, tamaño, puerto (10), y 'true' para exigir confirmación (ACK)
  int state = node.sendReceive(miPayload, tamano, 10, true);

  // RADIOLIB_ERR_NONE (0) significa que el proceso fue exitoso (ACK recibido)
  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Confirmación (ACK) recibida con éxito desde el Gateway!");
    return true;
  } else {
    Serial.print("Error al transmitir o sin confirmación. Código: ");
    Serial.println(state);
    return false;
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("Iniciando...");

  // Aquí inicializas SD, Sensores, LoRaWAN y LoRa P2P
  estacion.setDeviceId(2);

  estacion.u8g2.begin(); //pantalla
  Serial1.begin(9600);

  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  estacion.ds18b20.begin(); 

  if (!estacion.bme.begin(0x76)) { 
    Serial.println("Fallo BME680");
  } else {
    estacion.bme.setTemperatureOversampling(BME680_OS_8X);
    estacion.bme.setHumidityOversampling(BME680_OS_2X);
    estacion.bme.setPressureOversampling(BME680_OS_4X);
    estacion.bme.setIIRFilterSize(BME680_FILTER_SIZE_3);
    estacion.bme.setGasHeater(320, 150); 
  }

  Serial.println("--- Iniciando BastWAN con RadioLib ---");
  // Inicializar la radio física
  Serial.print("Inicializando chip de radio SX1276... ");
  int state = radio.begin();
  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Éxito!");
  } else {
    Serial.print("Falló el hardware. Código de error: ");
    Serial.println(state);
    while (true);
  }

  // Inicializar el nodo LoRaWAN con las llaves
  Serial.print("Configurando nodo LoRaWAN... ");
  state = node.beginOTAA(joinEUI, devEUI, newKey, appKey);
  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Listo!");
  } else {
    Serial.print("Error al configurar OTAA: ");
    Serial.println(state);
    while (true);
  }

  // Intentar unirse a TTN (Join)
  Serial.println("Solicitando Join por OTAA a la red...");
  state = node.activateOTAA();
  
  
  if (state == RADIOLIB_LORAWAN_NEW_SESSION) {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(1000);
    Serial.println("----------------------------------------------");
    Serial.println("¡Unión exitosa! Sesión establecida en TTN.");
    Serial.println("----------------------------------------------");
  } else {
    Serial.println("----------------------------------------------");
    Serial.print("No se pudo unir. Código de error: ");
    Serial.println(state);
    Serial.println("----------------------------------------------");
  }
  digitalWrite(LED_BUILTIN, LOW);

}

void loop() {
  
  // =========================================================================
  // 1) LEER SENSORES Y MOSTRAR LECTURA
  // =========================================================================
  // - Llama a tu función de lectura de sensores
  estacion.etapa2_leerSensoresYGPS();

  // - Muestra los valores por puerto serie/pantalla
  Serial.print("Temp BME680: "); 
  Serial.println(estacion.medicionActual.tempBME);
  Serial.print("Temp DS18B2: "); 
  Serial.println(estacion.medicionActual.tempDS18B20);
  estacion.actualizar_pantalla();

  // =========================================================================
  // 2) EMPAQUETAR Y 2.5) IMPRIMIR PAYLOAD
  // =========================================================================
  // - Empaqueta la lectura en tu variable 'payload_local'
  Serial.println("Ejecutando Etapa 3: Empaquetando datos LoRa...");
  int bytesLoRa = estacion.etapa3_prepararDatos(payload, huella);
  Serial.print("Bytes empaquetados para LoRa: "); Serial.println(bytesLoRa);

  // - Imprime el payload en formato HEX por el puerto serie para depuración
  estacion.imprimirPayloadEstructurado(payload);

  // =========================================================================
  // 3) INTENTAR ENVIAR POR LORAWAN (OTAA)
  // =========================================================================
  bool loraWAN_exitoso = false;
  int intentos = 3; 

  if (node.isActivated()) {
    node.setDatarate(3);
    while (intentos > 0 && !loraWAN_exitoso) {
      loraWAN_exitoso = enviarArregloDirecto(payload, sizeof(payload));

      if (loraWAN_exitoso) {
        digitalWrite(LED_BUILTIN, HIGH);
        delay(100);
        Serial.println(">>> Ciclo completado con éxito. <<<");
      } else {
        intentos--;
        Serial.print("Intento fallido. Intentos restantes: ");
        Serial.println(intentos);
        digitalWrite(LED_BUILTIN, HIGH);
        delay(1000);
        digitalWrite(LED_BUILTIN, LOW);
        delay(1000);
        digitalWrite(LED_BUILTIN, HIGH);
        delay(1000);
        digitalWrite(LED_BUILTIN, LOW);
        if (intentos > 0) {
          delay(10000); // Respiro de 10 segundos
        }
      }
      digitalWrite(LED_BUILTIN, LOW);
    }

    if (!loraWAN_exitoso) {
      Serial.println("ALERTA: El paquete se perdió permanentemente.");
    }

  } else {
    Serial.println("Dispositivo desconectado de TTN OTAA. Intentando unirse de nuevo...");
    node.activateOTAA();
  }

  // --- Retardo/Sleep del ciclo principal ---
  // =========================================================================
  // F) GUARDAR SD Si no se pudo por LoraWAN ni P2P 
  // =========================================================================

  delay(30000); // Esperar un tiempo antes de volver a leer sensores
}